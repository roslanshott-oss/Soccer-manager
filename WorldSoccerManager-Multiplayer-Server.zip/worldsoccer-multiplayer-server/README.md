# World Soccer Manager — Multiplayer Server

This is the first working multiplayer backend for the Android WebView app.
It provides:
- player join/session
- online manager list
- create/join league
- real-time chat
- `/health` and `/api/status` endpoints
- Socket.IO real-time transport

## Deploy on Render
1. Put this folder in a GitHub repository.
2. In Render, create a **New Web Service** and connect that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. After deploy, use the HTTPS URL Render gives you, e.g. `https://your-service.onrender.com`.
6. Replace the Android app's placeholder URL in `MainActivity.kt` with that HTTPS URL, then rebuild the APK.

## Important
This starter version keeps multiplayer state in memory. On a free/ephemeral server, data can reset after a restart/sleep. For persistent accounts, teams, transfers, standings and seasons, add PostgreSQL (or another persistent database) in the next stage.
