# World Soccer Manager Android

## GitHub Actions build

This project uses Android Gradle Plugin 9.4.0 with Gradle 9.6.0 and Java 17.

AGP 9+ provides built-in Kotlin support, so this project intentionally does not apply the `org.jetbrains.kotlin.android` Gradle plugin.

The GitHub Actions workflow should extract this ZIP and run:

`gradle assembleDebug --no-daemon`

The generated debug APK is:

`app/build/outputs/apk/debug/app-debug.apk`
