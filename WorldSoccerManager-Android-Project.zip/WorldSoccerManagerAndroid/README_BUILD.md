# World Soccer Manager — Android APK project

This is the Android wrapper for the real multiplayer web/backend version.

## Required before building
1. Deploy the Node.js + Socket.IO + PostgreSQL backend from `world-soccer-manager-online.zip` to a public HTTPS server.
2. Put your API-Football key ONLY in the backend `.env`:
   API_FOOTBALL_KEY=...
3. In `MainActivity.kt`, replace:
   https://YOUR-MULTIPLAYER-SERVER.example.com
   with your HTTPS backend URL.
4. Open this folder in Android Studio and Sync.
5. Build > Build APK(s).

Android requires release APKs to be signed. For Google Play, use an AAB and Play App Signing; a directly installable APK can be produced for testing/distribution.

## Important
The APK itself cannot safely contain the API-Football secret. The app talks to your server, and your server talks to API-Football.
